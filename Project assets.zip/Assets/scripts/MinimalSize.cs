﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MinimalSize : MonoBehaviour
{
    public float minimalBallSize = 1.0f;
}
